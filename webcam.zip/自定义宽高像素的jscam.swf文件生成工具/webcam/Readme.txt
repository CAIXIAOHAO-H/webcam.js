﻿1、change the width/height in jscam.xml and jscam.as
2、execute the commands below

commands:
1、swfmill simple src/jscam.xml jscam.swf
2、swfmill swf2xml jscam.swf src/jscam-source.xml
   ----change the objectID to 1 in jscam-source.xml
3、swfmill simple src/jscam-source.xml jscam.swf
4、mtasc -v -swf jscam.swf -main jscam.as -version 8 -cp src